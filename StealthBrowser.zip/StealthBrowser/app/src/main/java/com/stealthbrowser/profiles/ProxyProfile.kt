package com.stealthbrowser.profiles

import java.util.UUID

data class ProxyProfile(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var type: ProxyType,
    var host: String,
    var port: Int,
    var username: String = "",
    var password: String = "",
    var fingerprint: FingerprintProfile = FingerprintProfile()
)

enum class ProxyType {
    HTTP, HTTPS, SOCKS4, SOCKS5
}
