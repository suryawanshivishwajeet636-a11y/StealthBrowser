package com.stealthbrowser

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.stealthbrowser.ui.BrowserFragment
import com.stealthbrowser.ui.ProfilesFragment
import com.stealthbrowser.wipe.DataWiper
import com.stealthbrowser.wipe.WipeScheduler

class MainActivity : AppCompatActivity() {

    private lateinit var browserFragment: BrowserFragment
    private lateinit var profilesFragment: ProfilesFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Root layout
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // Address bar row
        val addressBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
        }
        val urlInput = EditText(this).apply {
            hint    = "Enter URL or search..."
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { v, _, _ ->
                browserFragment.navigate(v.text.toString())
                true
            }
        }
        val goBtn = Button(this).apply {
            text = "Go"
            setOnClickListener { browserFragment.navigate(urlInput.text.toString()) }
        }
        addressBar.addView(urlInput)
        addressBar.addView(goBtn)

        // Fragment container
        val container = FrameLayout(this).apply {
            id = android.R.id.content + 1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        // Bottom nav
        val bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val btnBrowser  = Button(this).apply {
            text = "Browser"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { showFragment(browserFragment) }
        }
        val btnProfiles = Button(this).apply {
            text = "Profiles"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { showFragment(profilesFragment) }
        }
        val btnWipe = Button(this).apply {
            text = "Wipe Now"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                browserFragment.nukeSession()
                DataWiper(this@MainActivity).wipeAll()
                Toast.makeText(this@MainActivity, "Session wiped.", Toast.LENGTH_SHORT).show()
            }
        }
        bottomNav.addView(btnBrowser)
        bottomNav.addView(btnProfiles)
        bottomNav.addView(btnWipe)

        root.addView(addressBar)
        root.addView(container)
        root.addView(bottomNav)
        setContentView(root)

        browserFragment  = BrowserFragment()
        profilesFragment = ProfilesFragment()

        if (savedInstanceState == null) {
            showFragment(browserFragment)
        }

        WipeScheduler.start(this)
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(android.R.id.content + 1, fragment)
            .commit()
    }

    override fun onBackPressed() {
        if (browserFragment.isVisible && browserFragment.canGoBack()) {
            browserFragment.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        DataWiper(this).wipeAll()
        super.onDestroy()
    }
}
