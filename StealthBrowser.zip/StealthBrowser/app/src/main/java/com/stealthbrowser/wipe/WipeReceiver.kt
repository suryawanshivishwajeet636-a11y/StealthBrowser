package com.stealthbrowser.wipe

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class WipeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Thread { DataWiper(context).wipeAll() }.start()
    }
}
