package com.stealthbrowser.browser

import com.stealthbrowser.profiles.FingerprintProfile

object JSInjector {

    fun buildInjectionScript(fp: FingerprintProfile): String {
        return """
(function() {
    'use strict';

    // Navigator
    const navProps = {
        userAgent:           '${fp.userAgent}',
        platform:            '${fp.platform}',
        language:            '${fp.language}',
        languages:           ${fp.languages.map { "'$it'" }},
        hardwareConcurrency: ${fp.hardwareConcurrency},
        deviceMemory:        ${fp.deviceMemory},
        maxTouchPoints:      ${fp.maxTouchPoints},
        doNotTrack:          ${if (fp.doNotTrack != null) "'${fp.doNotTrack}'" else "null"},
    };
    for (const [key, val] of Object.entries(navProps)) {
        try {
            Object.defineProperty(navigator, key, {
                get: () => Array.isArray(val) ? Object.freeze([...val]) : val,
                configurable: true
            });
        } catch(e) {}
    }

    // Screen
    Object.defineProperty(window, 'devicePixelRatio', { get: () => ${fp.devicePixelRatio} });
    Object.defineProperty(screen, 'width',       { get: () => ${fp.screenWidth} });
    Object.defineProperty(screen, 'height',      { get: () => ${fp.screenHeight} });
    Object.defineProperty(screen, 'availWidth',  { get: () => ${fp.screenWidth} });
    Object.defineProperty(screen, 'availHeight', { get: () => ${fp.screenHeight} - 48 });
    Object.defineProperty(screen, 'colorDepth',  { get: () => ${fp.colorDepth} });
    Object.defineProperty(screen, 'pixelDepth',  { get: () => ${fp.pixelDepth} });

    // Canvas noise
    const _toDataURL    = HTMLCanvasElement.prototype.toDataURL;
    const _getImageData = CanvasRenderingContext2D.prototype.getImageData;
    const seed = ${fp.canvasSeed};

    function lcg(s) { return ((Math.imul(1664525, s) + 1013904223) | 0) >>> 0; }

    HTMLCanvasElement.prototype.toDataURL = function(...args) {
        const ctx = this.getContext('2d');
        if (ctx) {
            const id = ctx.getImageData(0, 0, this.width, this.height);
            let s = seed;
            for (let i = 0; i < id.data.length; i += 4) {
                s = lcg(s);
                id.data[i]   = Math.min(255, id.data[i]   + (s % 3));
                id.data[i+1] = Math.min(255, id.data[i+1] + (s % 3));
                id.data[i+2] = Math.min(255, id.data[i+2] + (s % 3));
            }
            ctx.putImageData(id, 0, 0);
        }
        return _toDataURL.apply(this, args);
    };

    CanvasRenderingContext2D.prototype.getImageData = function(...args) {
        const id = _getImageData.apply(this, args);
        let s = seed;
        for (let i = 0; i < id.data.length; i += 4) {
            s = lcg(s);
            id.data[i] = Math.min(255, id.data[i] + (s % 3));
        }
        return id;
    };

    // WebGL
    const _getParam   = WebGLRenderingContext.prototype.getParameter;
    const _getParamEx = typeof WebGL2RenderingContext !== 'undefined'
                        ? WebGL2RenderingContext.prototype.getParameter : null;

    function spoofGL(orig) {
        return function(param) {
            if (param === 37445) return '${fp.webGLVendor}';
            if (param === 37446) return '${fp.webGLRenderer}';
            if (param === 7936)  return 'WebKit';
            if (param === 7937)  return 'WebKit WebGL';
            const r = orig.call(this, param);
            if (r instanceof Float32Array && ${fp.webGLNoise}) {
                const noise = new Float32Array(r);
                for (let i = 0; i < noise.length; i++) noise[i] += (Math.random() - 0.5) * 0.0001;
                return noise;
            }
            return r;
        };
    }
    WebGLRenderingContext.prototype.getParameter = spoofGL(_getParam);
    if (_getParamEx) WebGL2RenderingContext.prototype.getParameter = spoofGL(_getParamEx);

    // Audio noise
    if (typeof AudioContext !== 'undefined') {
        const _createAnalyser = AudioContext.prototype.createAnalyser;
        AudioContext.prototype.createAnalyser = function() {
            const analyser = _createAnalyser.call(this);
            const _getFloat = analyser.getFloatFrequencyData.bind(analyser);
            analyser.getFloatFrequencyData = function(arr) {
                _getFloat(arr);
                for (let i = 0; i < arr.length; i++) arr[i] += (Math.random() - 0.5) * ${fp.audioNoise};
            };
            return analyser;
        };
    }

    // Timezone
    const _DateTimeFormat = Intl.DateTimeFormat;
    function FakeDTF(loc, opts = {}) {
        opts.timeZone = opts.timeZone || '${fp.timezone}';
        return new _DateTimeFormat(loc, opts);
    }
    FakeDTF.prototype = _DateTimeFormat.prototype;
    Intl.DateTimeFormat = FakeDTF;
    Date.prototype.getTimezoneOffset = function() { return ${fp.timezoneOffset}; };

    // WebRTC block
    ${if (fp.blockWebRTC) """
    window.RTCPeerConnection       = undefined;
    window.webkitRTCPeerConnection = undefined;
    window.mozRTCPeerConnection    = undefined;
    window.RTCIceCandidate         = undefined;
    window.RTCSessionDescription   = undefined;
    """ else ""}

    // Battery
    if (navigator.getBattery) {
        navigator.getBattery = () => Promise.resolve({
            charging:            ${fp.batteryCharging},
            chargingTime:        ${if (fp.batteryCharging) "3600" else "Infinity"},
            dischargingTime:     ${if (!fp.batteryCharging) "7200" else "Infinity"},
            level:               ${fp.batteryLevel},
            addEventListener:    () => {},
            removeEventListener: () => {}
        });
    }

    // Network info
    if (navigator.connection) {
        Object.defineProperty(navigator, 'connection', {
            get: () => ({
                effectiveType:       '${fp.connectionType}',
                type:                '${fp.connectionType}',
                downlink:            ${fp.downlink},
                rtt:                 ${fp.rtt},
                saveData:            false,
                addEventListener:    () => {},
                removeEventListener: () => {}
            }),
            configurable: true
        });
    }

    // Media devices
    ${if (fp.spoofMediaDevices) """
    if (navigator.mediaDevices) {
        navigator.mediaDevices.enumerateDevices = () => Promise.resolve([
            { deviceId: 'default', kind: 'audioinput',  label: '', groupId: 'default' },
            { deviceId: 'default', kind: 'audiooutput', label: '', groupId: 'default' },
            { deviceId: 'default', kind: 'videoinput',  label: '', groupId: 'default' }
        ]);
    }
    """ else ""}

    // Permissions
    ${if (fp.spoofPermissions) """
    const _query = navigator.permissions?.query?.bind(navigator.permissions);
    if (_query) {
        navigator.permissions.query = (perm) => Promise.resolve({
            state:               'denied',
            onchange:            null,
            addEventListener:    () => {},
            removeEventListener: () => {}
        });
    }
    """ else ""}

    // Keyboard
    ${if (fp.spoofKeyboard) """
    Object.defineProperty(navigator, 'keyboard', { get: () => undefined, configurable: true });
    """ else ""}

    // Fonts
    if (document.fonts) {
        const allowedFonts = new Set(${fp.fonts.map { "'$it'" }});
        const _check = document.fonts.check.bind(document.fonts);
        document.fonts.check = (font, text) => {
            const name = font.replace(/['"]/g,'').split(' ').pop();
            return allowedFonts.has(name) ? _check(font, text) : false;
        };
    }

    // Plugins / MimeTypes
    Object.defineProperty(navigator, 'plugins', {
        get: () => Object.create(PluginArray.prototype), configurable: true
    });
    Object.defineProperty(navigator, 'mimeTypes', {
        get: () => Object.create(MimeTypeArray.prototype), configurable: true
    });

    // Automation flags
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined, configurable: true });
    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;

})();
        """.trimIndent()
    }
}
