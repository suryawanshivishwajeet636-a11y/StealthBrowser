package com.stealthbrowser.ui

import android.os.Bundle
import android.view.*
import android.webkit.WebView
import androidx.fragment.app.Fragment
import com.stealthbrowser.browser.StealthWebView
import com.stealthbrowser.profiles.ProfileManager

class BrowserFragment : Fragment() {

    private lateinit var webView: StealthWebView
    private lateinit var profileManager: ProfileManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        profileManager = ProfileManager(requireContext())
        webView = StealthWebView(requireContext())

        val active = profileManager.getActive()
        if (active != null) {
            webView.applyProfile(active)
            webView.loadUrl("https://www.google.com")
        }

        return webView
    }

    fun navigate(url: String) {
        val finalUrl = if (url.startsWith("http")) url else "https://$url"
        webView.loadUrl(finalUrl)
    }

    fun nukeSession() = webView.nukeSession()

    fun canGoBack() = webView.canGoBack()
    fun goBack()    = webView.goBack()

    override fun onDestroyView() {
        webView.destroy()
        super.onDestroyView()
    }
}
