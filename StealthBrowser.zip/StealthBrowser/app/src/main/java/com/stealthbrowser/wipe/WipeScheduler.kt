package com.stealthbrowser.wipe

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class WipeScheduler : Service() {

    companion object {
        const val CHANNEL_ID    = "wipe_channel"
        const val NOTIF_ID      = 1001
        const val WIPE_INTERVAL = 60 * 60 * 1000L  // 1 hour

        fun start(context: Context) {
            context.startForegroundService(Intent(context, WipeScheduler::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WipeScheduler::class.java))
        }
    }

    private val wiper by lazy { DataWiper(this) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private val wipeRunnable = object : Runnable {
        override fun run() {
            Thread { wiper.wipeAll() }.start()
            handler.postDelayed(this, WIPE_INTERVAL)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        handler.postDelayed(wipeRunnable, WIPE_INTERVAL)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(wipeRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID, "StealthBrowser", NotificationManager.IMPORTANCE_MIN
        ).apply { setShowBadge(false) }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("StealthBrowser")
            .setContentText("Session protection active")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setSilent(true)
            .build()
    }
}
