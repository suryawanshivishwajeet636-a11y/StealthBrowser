package com.stealthbrowser.browser

import android.content.Context
import android.os.Build
import android.webkit.WebViewClient
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import com.stealthbrowser.profiles.ProxyProfile
import com.stealthbrowser.profiles.ProxyType
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.Executor

class ProxyManager(private val context: Context) {

    fun buildProxyForWebView(profile: ProxyProfile): WebViewClient {
        return when (profile.type) {
            ProxyType.HTTP, ProxyType.HTTPS -> buildHttpProxy(profile)
            ProxyType.SOCKS4, ProxyType.SOCKS5 -> buildSocksProxy(profile)
        }
    }

    private fun buildHttpProxy(profile: ProxyProfile): WebViewClient {
        System.setProperty("http.proxyHost", profile.host)
        System.setProperty("http.proxyPort", profile.port.toString())
        System.setProperty("https.proxyHost", profile.host)
        System.setProperty("https.proxyPort", profile.port.toString())

        return object : WebViewClient() {
            override fun onReceivedHttpAuthRequest(
                view: android.webkit.WebView?,
                handler: android.webkit.HttpAuthHandler?,
                host: String?,
                realm: String?
            ) {
                if (profile.username.isNotEmpty()) {
                    handler?.proceed(profile.username, profile.password)
                } else {
                    super.onReceivedHttpAuthRequest(view, handler, host, realm)
                }
            }
        }
    }

    private fun buildSocksProxy(profile: ProxyProfile): WebViewClient {
        System.setProperty("socksProxyHost", profile.host)
        System.setProperty("socksProxyPort", profile.port.toString())
        if (profile.username.isNotEmpty()) {
            System.setProperty("java.net.socks.username", profile.username)
            System.setProperty("java.net.socks.password", profile.password)
        }
        applyWebViewProxyModern(profile)
        return object : WebViewClient() {}
    }

    private fun applyWebViewProxyModern(profile: ProxyProfile) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val proxyConfig = ProxyConfig.Builder()
                .addProxyRule("${profile.host}:${profile.port}")
                .build()
            val executor = Executor { runnable -> runnable.run() }
            ProxyController.getInstance().setProxyOverride(proxyConfig, executor) {}
        }
    }

    fun clearProxy() {
        System.clearProperty("http.proxyHost")
        System.clearProperty("http.proxyPort")
        System.clearProperty("https.proxyHost")
        System.clearProperty("https.proxyPort")
        System.clearProperty("socksProxyHost")
        System.clearProperty("socksProxyPort")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ProxyController.getInstance().clearProxyOverride({ runnable -> runnable.run() }) {}
        }
    }

    fun buildJavaProxy(profile: ProxyProfile): Proxy {
        val type = when (profile.type) {
            ProxyType.SOCKS4, ProxyType.SOCKS5 -> Proxy.Type.SOCKS
            else -> Proxy.Type.HTTP
        }
        return Proxy(type, InetSocketAddress(profile.host, profile.port))
    }
}
