package com.stealthbrowser.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.stealthbrowser.profiles.ProfileManager
import com.stealthbrowser.profiles.ProxyProfile
import com.stealthbrowser.profiles.ProxyType

class ProfilesFragment : Fragment() {

    private lateinit var profileManager: ProfileManager
    private lateinit var listView: ListView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        profileManager = ProfileManager(requireContext())

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val addButton = Button(requireContext()).apply {
            text = "Add Profile"
            setOnClickListener { showAddDialog() }
        }

        listView = ListView(requireContext())
        refreshList()

        layout.addView(addButton)
        layout.addView(listView)
        return layout
    }

    private fun refreshList() {
        val profiles = profileManager.getAll()
        val names    = profiles.map { "${it.name} (${it.type} ${it.host}:${it.port})" }
        listView.adapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_list_item_1, names
        )
        listView.setOnItemClickListener { _, _, pos, _ ->
            profileManager.setActive(profiles[pos].id)
            Toast.makeText(requireContext(), "Profile activated: ${profiles[pos].name}", Toast.LENGTH_SHORT).show()
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            profileManager.delete(profiles[pos].id)
            refreshList()
            true
        }
    }

    private fun showAddDialog() {
        val ctx = requireContext()
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 16)
        }

        fun field(hint: String) = EditText(ctx).apply {
            this.hint = hint
            layout.addView(this)
        }

        val nameField = field("Profile name")
        val hostField = field("Proxy host (e.g. 127.0.0.1)")
        val portField = field("Port (e.g. 1080)")
        val userField = field("Username (optional)")
        val passField = field("Password (optional)")

        val typeSpinner = Spinner(ctx).apply {
            adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_item,
                ProxyType.values().map { it.name })
            layout.addView(this)
        }

        android.app.AlertDialog.Builder(ctx)
            .setTitle("New Proxy Profile")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val profile = ProxyProfile(
                    name     = nameField.text.toString().ifEmpty { "Profile" },
                    type     = ProxyType.valueOf(typeSpinner.selectedItem.toString()),
                    host     = hostField.text.toString(),
                    port     = portField.text.toString().toIntOrNull() ?: 1080,
                    username = userField.text.toString(),
                    password = passField.text.toString()
                )
                profileManager.add(profile)
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
