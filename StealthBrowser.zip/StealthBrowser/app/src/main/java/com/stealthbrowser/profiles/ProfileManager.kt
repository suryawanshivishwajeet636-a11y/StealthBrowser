package com.stealthbrowser.profiles

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ProfileManager(context: Context) {

    private val prefs = context.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    private val gson  = Gson()
    private val key   = "proxy_profiles"

    fun getAll(): MutableList<ProxyProfile> {
        val json = prefs.getString(key, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<ProxyProfile>>() {}.type
        return gson.fromJson(json, type)
    }

    fun save(profiles: List<ProxyProfile>) {
        prefs.edit().putString(key, gson.toJson(profiles)).apply()
    }

    fun add(profile: ProxyProfile) {
        val list = getAll()
        list.add(profile)
        save(list)
    }

    fun update(profile: ProxyProfile) {
        val list = getAll()
        val idx = list.indexOfFirst { it.id == profile.id }
        if (idx >= 0) { list[idx] = profile; save(list) }
    }

    fun delete(id: String) {
        val list = getAll().filter { it.id != id }
        save(list)
    }

    fun getActive(): ProxyProfile? {
        val id = prefs.getString("active_id", null) ?: return null
        return getAll().firstOrNull { it.id == id }
    }

    fun setActive(id: String) {
        prefs.edit().putString("active_id", id).apply()
    }
}
