package com.stealthbrowser.browser

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.*
import com.stealthbrowser.profiles.FingerprintProfile
import com.stealthbrowser.profiles.ProxyProfile

@SuppressLint("SetJavaScriptEnabled")
class StealthWebView(context: Context) : WebView(context) {

    private val proxyManager = ProxyManager(context)
    private var currentProfile: ProxyProfile? = null

    init {
        applySecureSettings()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySecureSettings() {
        with(settings) {
            javaScriptEnabled        = true
            domStorageEnabled        = true
            databaseEnabled          = true
            allowFileAccess          = false
            allowContentAccess       = false
            mixedContentMode         = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode                = WebSettings.LOAD_NO_CACHE
            saveFormData             = false
            savePassword             = false
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            loadsImagesAutomatically = true
            builtInZoomControls      = true
            displayZoomControls      = false
            setSupportMultipleWindows(false)
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(this@StealthWebView, false)
        }
    }

    fun applyProfile(profile: ProxyProfile) {
        currentProfile = profile
        settings.userAgentString = profile.fingerprint.userAgent
        val baseClient = proxyManager.buildProxyForWebView(profile)
        webViewClient  = buildFingerprintClient(profile.fingerprint, baseClient)
    }

    private fun buildFingerprintClient(
        fp: FingerprintProfile,
        base: WebViewClient
    ): WebViewClient {
        val script = JSInjector.buildInjectionScript(fp)
        return object : WebViewClient() {
            override fun onPageStarted(
                view: WebView?, url: String?, favicon: android.graphics.Bitmap?
            ) {
                view?.evaluateJavascript(script, null)
                base.onPageStarted(view, url, favicon)
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView?, handler: HttpAuthHandler?, host: String?, realm: String?
            ) {
                val p = currentProfile
                if (p != null && p.username.isNotEmpty()) {
                    handler?.proceed(p.username, p.password)
                } else {
                    super.onReceivedHttpAuthRequest(view, handler, host, realm)
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                val scheme = request?.url?.scheme ?: return false
                return scheme !in listOf("http", "https", "mailto", "tel")
            }
        }
    }

    fun nukeSession() {
        stopLoading()
        clearCache(true)
        clearHistory()
        clearFormData()
        clearSslPreferences()
        CookieManager.getInstance().apply {
            removeAllCookies(null)
            flush()
        }
        WebStorage.getInstance().deleteAllData()
    }
}
