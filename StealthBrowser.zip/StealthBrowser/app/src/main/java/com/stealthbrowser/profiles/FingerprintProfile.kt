package com.stealthbrowser.profiles

data class FingerprintProfile(
    var userAgent: String = FingerprintDefaults.randomUA(),
    var platform: String = "Linux armv8l",
    var language: String = "en-US",
    var languages: List<String> = listOf("en-US", "en"),
    var doNotTrack: String? = "1",
    var hardwareConcurrency: Int = (2..8 step 2).toList().random(),
    var deviceMemory: Int = listOf(2, 4, 8).random(),
    var maxTouchPoints: Int = listOf(0, 1, 5, 10).random(),
    var screenWidth: Int = listOf(360, 375, 390, 412, 414).random(),
    var screenHeight: Int = listOf(640, 720, 844, 915, 932).random(),
    var colorDepth: Int = 24,
    var pixelDepth: Int = 24,
    var devicePixelRatio: Double = listOf(1.0, 2.0, 2.75, 3.0).random(),
    var canvasNoise: Float = (1..9).random() * 0.0001f,
    var canvasSeed: Long = System.nanoTime(),
    var webGLVendor: String = FingerprintDefaults.randomGLVendor(),
    var webGLRenderer: String = FingerprintDefaults.randomGLRenderer(),
    var webGLNoise: Boolean = true,
    var audioNoise: Double = Math.random() * 0.0001,
    var timezone: String = FingerprintDefaults.randomTimezone(),
    var timezoneOffset: Int = 0,
    var fonts: List<String> = FingerprintDefaults.randomFontSet(),
    var batteryCharging: Boolean = listOf(true, false).random(),
    var batteryLevel: Double = (20..95).random() / 100.0,
    var connectionType: String = listOf("wifi", "4g").random(),
    var downlink: Double = listOf(1.5, 5.0, 10.0, 50.0).random(),
    var rtt: Int = listOf(50, 100, 150).random(),
    var spoofPermissions: Boolean = true,
    var blockWebRTC: Boolean = true,
    var spoofMediaDevices: Boolean = true,
    var spoofKeyboard: Boolean = true
)

object FingerprintDefaults {
    fun randomUA(): String {
        val uas = listOf(
            "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 11; OnePlus 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Linux; Android 12; Redmi Note 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36"
        )
        return uas.random()
    }

    fun randomGLVendor(): String = listOf(
        "Qualcomm", "ARM", "Imagination Technologies", "NVIDIA Corporation"
    ).random()

    fun randomGLRenderer(): String = listOf(
        "Adreno (TM) 650", "Mali-G78 MP14", "PowerVR GT7600 Plus", "Tegra K1"
    ).random()

    fun randomTimezone(): String = listOf(
        "America/New_York", "Europe/London", "Asia/Tokyo",
        "America/Los_Angeles", "Europe/Berlin", "Asia/Singapore"
    ).random()

    fun randomFontSet(): List<String> = listOf(
        "Arial", "Helvetica", "Times New Roman", "Courier New",
        "Verdana", "Georgia", "Trebuchet MS", "Impact"
    ).shuffled().take((4..8).random())
}
