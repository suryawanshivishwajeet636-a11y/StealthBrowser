package com.stealthbrowser.wipe

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import java.io.File

class DataWiper(private val context: Context) {

    fun wipeAll() {
        wipeCookies()
        wipeWebStorage()
        wipeCache()
        wipeDatabase()
        wipeSharedPrefsExceptProfiles()
        wipeFiles()
    }

    private fun wipeCookies() {
        CookieManager.getInstance().apply {
            removeAllCookies(null)
            flush()
        }
    }

    private fun wipeWebStorage() {
        WebStorage.getInstance().deleteAllData()
    }

    private fun wipeCache() {
        context.cacheDir.deleteRecursively()
        File(context.applicationInfo.dataDir, "cache").deleteRecursively()
        File(context.applicationInfo.dataDir, "app_webview/Cache").deleteRecursively()
        File(context.applicationInfo.dataDir, "app_webview/Code Cache").deleteRecursively()
    }

    private fun wipeDatabase() {
        File(context.applicationInfo.dataDir, "app_webview/databases").deleteRecursively()
        File(context.applicationInfo.dataDir, "app_webview/Local Storage").deleteRecursively()
        File(context.applicationInfo.dataDir, "app_webview/IndexedDB").deleteRecursively()
        File(context.applicationInfo.dataDir, "app_webview/Service Worker").deleteRecursively()
        File(context.applicationInfo.dataDir, "app_webview/Session Storage").deleteRecursively()
    }

    private fun wipeSharedPrefsExceptProfiles() {
        val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
        prefsDir.listFiles()?.forEach { file ->
            if (!file.name.contains("profiles")) {
                file.delete()
            }
        }
    }

    private fun wipeFiles() {
        context.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        context.getExternalFilesDir(null)?.deleteRecursively()
    }
}
