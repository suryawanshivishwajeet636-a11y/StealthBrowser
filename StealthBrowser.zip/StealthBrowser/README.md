# StealthBrowser

Full antidetect Android browser with multi-proxy support and maximum fingerprint spoofing.

---

## Requirements
- PC/Mac/Linux with Android Studio installed
- Android Studio: https://developer.android.com/studio
- Android phone running Android 9 (API 28) or above

---

## Setup Steps

1. Open Android Studio
2. File → Open → select this StealthBrowser folder
3. Wait for Gradle sync (click "Sync Now" if prompted)
4. Connect your Android phone via USB with USB Debugging enabled
5. Click the green ▶ Run button

---

## Features

| Feature | Detail |
|---|---|
| Proxy types | HTTP, HTTPS, SOCKS4, SOCKS5 with auth |
| Proxy profiles | Multiple profiles, tap to switch |
| Fingerprint spoof | Navigator, Screen, Canvas, WebGL, Audio, Timezone, WebRTC, Battery, Network, Media, Permissions, Fonts, Plugins |
| Session wipe | Every 1 hour automatically + manual Wipe Now button + on app close |
| Wipe scope | Cookies, Cache, WebStorage, IndexedDB, Service Worker, Local Storage, Session Storage |
| Anti-automation | webdriver flag removed, CDP tokens deleted |

---

## How to use

1. Tap **Profiles** → **Add Profile** → enter proxy details → Save
2. Tap the profile to activate it
3. Tap **Browser** → browse normally through your proxy
4. Tap **Wipe Now** anytime to instantly clear the session

---

## File Map

```
app/src/main/java/com/stealthbrowser/
├── MainActivity.kt              — main UI, address bar, bottom nav
├── browser/
│   ├── StealthWebView.kt        — hardened WebView
│   ├── ProxyManager.kt          — HTTP/SOCKS proxy routing
│   └── JSInjector.kt            — full fingerprint spoof JS
├── profiles/
│   ├── ProxyProfile.kt          — proxy data model
│   ├── FingerprintProfile.kt    — fingerprint data + randomizers
│   └── ProfileManager.kt       — CRUD + active profile
├── wipe/
│   ├── DataWiper.kt             — full data nuke
│   ├── WipeScheduler.kt         — hourly foreground service
│   └── WipeReceiver.kt          — broadcast receiver
└── ui/
    ├── BrowserFragment.kt       — browser screen
    └── ProfilesFragment.kt      — profile manager screen
```
